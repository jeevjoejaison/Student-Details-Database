#include <iostream>
#include <sstream>
#include <vector>
#include <openssl/sha.h>
#include <iomanip>
#include<bits/stdc++.h>

using namespace std; 


// inp.c_str() → Converts the input string to a const char* (C-style string).
// (const unsigned char*)inp.c_str() → Casts it to unsigned char*, required by SHA256().
// inp.size() → Gets the length of the input string.
string sha3_256(const string &inp){
    //returns strng which is hexadecimal hash of inp
    unsigned char hash[SHA256_DIGEST_LENGTH]; // create storage for hash def in open ssl
    SHA256((const unsigned char*)inp.c_str(),inp.size(),hash);

    stringstream ss;
    for(int i=0;i<SHA256_DIGEST_LENGTH;i++){
        ss<<hex<<setw(2)<<setfill('0')<<(int)hash[i];
    }
    return ss.str();
}

struct Transactions{
    char sender,reciever;
    int amount,incentives;
      
    string hash() const{
        string s1;
        s1.push_back(sender);
        string r1;
        r1.push_back(reciever);    
        return sha3_256(s1+to_string(incentives)+r1+to_string(amount));
      }
    
};

//check transactions combine the transactions go on anding untill getting the root node

string MerkleRoot(vector<Transactions>&transactions){
    if(transactions.size()==0){
        return "";
    }
    // gen t1 t2 ...
    vector<string>leaf;
    for(int i=0;i<transactions.size();i++){
       leaf.push_back(transactions[i].hash());
    }
    
    while(leaf.size()>1){
        vector<string>nodes;
        for(int i=0;i<leaf.size();i+=2){
            string temp=leaf[i];
            if(i+1<leaf.size()){
                temp+=leaf[i+1];
            }
            nodes.push_back(sha3_256(temp));
        }
        leaf=nodes;
    }

return leaf[0];
}





struct Block{

  int block_number;
  string merkle_root;
  string block_hash;
  string prev_block_hash;
  vector<Transactions>Transaction;
  int nonce=0;
  Block(int num,string prev_hash,vector<Transactions>txn){
    block_number=num;
    prev_block_hash=prev_hash;
    Transaction=txn;
    merkle_root=MerkleRoot(txn);

    //block hash=prev_hash +blocknum+merkleroot;
    string bhash="";
    bhash=prev_hash+to_string(block_number)+merkle_root;
    block_hash=sha3_256(bhash);
    int number=0;
    string checker=sha3_256(bhash+to_string(number));
    while(checker[checker.size()-1]!='0'){
        number++;
        string temp=sha3_256(bhash+to_string(number));
        checker=temp;
    }
   nonce=number;
  }

  void printBlock(){
    cout<<block_number<<endl;
    cout<<block_hash<<endl;
    cout << "[";
      for (size_t i = 0; i < Transaction.size(); i++) {
        cout << "['" << Transaction[i].sender << "', '" << Transaction[i].reciever << "', " 
             << Transaction[i].amount << ", " << Transaction[i].incentives << "]";
        if (i != Transaction.size() - 1) cout << ", ";
    }
    cout << "]" << endl;
    cout << merkle_root << endl; 
    cout<<nonce<<endl;
}

};



static bool comp(Transactions &a,Transactions &b){
    if(a.incentives>b.incentives)return true;
    else if(a.incentives==b.incentives){
        if(a.reciever<b.reciever)return true;
        return false;
    }
    return false;
}

vector<Block>createblocks(int num_acc,map<char,int>mpp,int num_txn,vector<Transactions>txns){
   map<char,int>mpp1=mpp;
   sort(txns.begin(),txns.end(),comp);

   vector<int>vis(txns.size(),0);
   for(int i=0;i<txns.size();i++){
    int sendera=mpp1[txns[i].sender];
    int recievera=mpp1[txns[i].reciever];
    int to_send=txns[i].amount;
    if(sendera>=to_send){
        vis[i]=1;
        mpp1[txns[i].sender]-=to_send;
        mpp1[txns[i].reciever]+=to_send;
    }
    else{
        vis[i]=0;
    }
   }

vector<Transactions>validTxn;

   for(int i=0;i<vis.size();i++){
        if(vis[i]==1){
            validTxn.push_back(txns[i]);
        }
   }

  string prev_block_hash="0"; 

  vector<Block>blockchain;

   for(int i=0;i<validTxn.size();i+=4){
     vector<Transactions>temp;
     int n=validTxn.size();
     for(int j=i;j<min(i+4,n);j++){
        temp.push_back(validTxn[j]);
     }    
     Block newBlock(i/4 +1,prev_block_hash,temp);
     blockchain.push_back(newBlock);
     prev_block_hash=newBlock.block_hash;
   }

return blockchain;
}






int main(){
    int num_acc;
    cin>>num_acc;
    map<char,int>mpp;
    for(int i=0;i<num_acc;i++){
        char account;
        int balance;
        cin>>account>>balance;
        mpp[account]=balance;
    }
    int num_txn;
    cin>>num_txn;

    vector<Transactions>txn;
    for(int i=0;i<num_txn;i++){
        char sender,reciever;
        int balance,extra_data;
        cin>>sender>>reciever>>balance>>extra_data;
        Transactions temp;
        temp.sender=sender;
        temp.reciever=reciever;
        temp.amount=balance;
        temp.incentives=extra_data;
        txn.push_back(temp); 
    }

vector<Block>blockchain=createblocks(num_acc,mpp,num_txn,txn);
for (auto& block : blockchain) {
    block.printBlock();
}
    
}
