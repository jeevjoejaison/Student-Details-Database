#include <iostream>
#include <sstream>
#include <vector>
#include <openssl/sha.h>
#include <iomanip>
#include<bits/stdc++.h>

using namespace std; 


// inp.c_str() → Converts the input string to a const char* (C-style string).
// (const unsigned char*)inp.c_str() → Casts it to unsigned char*, required by SHA256().
// inp.size() → Gets the length of the input string.
string sha3_256(const string &inp){
    //returns strng which is hexadecimal hash of inp
    unsigned char hash[SHA256_DIGEST_LENGTH]; // create storage for hash def in open ssl
    SHA256((const unsigned char*)inp.c_str(),inp.size(),hash);

    stringstream ss;
    for(int i=0;i<SHA256_DIGEST_LENGTH;i++){
        ss<<hex<<setw(2)<<setfill('0')<<(int)hash[i];
    }
    return ss.str();
}

struct Transactions{
    char sender,reciever;
    int amount,incentives;
      
    string hash() const{
        string s1;
        s1.push_back(sender);
        string r1;
        r1.push_back(reciever);    
        return sha3_256(s1+to_string(incentives)+r1+to_string(amount));
      }
    
};

struct Miner {
    string id;
    int computation_score;
    vector<int> block_hash_score_array;
};
//check transactions combine the transactions go on anding untill getting the root node

string MerkleRoot(vector<Transactions>&transactions){
    if(transactions.size()==0){
        return "";
    }
    // gen t1 t2 ...
    vector<string>leaf;
    for(int i=0;i<transactions.size();i++){
       leaf.push_back(transactions[i].hash());
    }
    
    while(leaf.size()>1){
        vector<string>nodes;
        for(int i=0;i<leaf.size();i+=2){
            string temp=leaf[i];
            if(i+1<leaf.size()){
                temp+=leaf[i+1];
            }
            nodes.push_back(sha3_256(temp));
        }
        leaf=nodes;
    }

return leaf[0];
}



string findminer(vector<Miner>M,int blocknumber){
    int maxscore=-1;
    int idx=blocknumber%8;
    string answer="";
    for(int i=0;i<M.size();i++){
       int bss= M[i].computation_score*M[i].block_hash_score_array[idx];
       if(bss>maxscore){
        answer=M[i].id;
        maxscore=bss;
       }
    }
    return answer;
}




struct Block{

  int block_number;
  string merkle_root;
  string block_hash;
  string prev_block_hash;
  vector<Transactions>Transaction;
  int nonce=0;
  string bestminer;

  Block(int num,string prev_hash,vector<Transactions>txn,vector<Miner>miner){
    block_number=num;
    prev_block_hash=prev_hash;
    Transaction=txn;
    merkle_root=MerkleRoot(txn);
    bestminer=findminer(miner,block_number);
    //block hash=prev_hash +blocknum+merkleroot;
    string bhash="";
    bhash=prev_hash+to_string(block_number)+merkle_root;
    block_hash=sha3_256(bhash);
    int number=0;
    string checker=sha3_256(bhash+to_string(number));
    while(checker[checker.size()-1]!='0'){
        number++;
        string temp=sha3_256(bhash+to_string(number));
        checker=temp;
    }
   nonce=number;
  }

  void printBlock(){
    cout<<block_number<<endl;
    cout<<block_hash<<endl;
    cout << "[";
      for (size_t i = 0; i < Transaction.size(); i++) {
        cout << "['" << Transaction[i].sender << "', '" << Transaction[i].reciever << "', " 
             << Transaction[i].amount << ", " << Transaction[i].incentives << "]";
        if (i != Transaction.size() - 1) cout << ", ";
    }
    cout << "]" << endl;
    cout << merkle_root << endl; 
    cout<<nonce<<" "<<bestminer<<endl;
    
}

};







static bool comp(Transactions &a,Transactions &b){
    if(a.incentives>b.incentives)return true;
    else if(a.incentives==b.incentives){
        if(a.reciever<b.reciever)return true;
        return false;
    }
    return false;
}

vector<Block>createblocks(int num_acc,map<char,int>mpp,int num_txn,vector<Transactions>txns,vector<Miner>miner,int reward){
   map<char,int>mpp1=mpp;
   sort(txns.begin(),txns.end(),comp);
   string prev_block_hash="0";
   int blocknumber=1;
   int size=0;
   vector<Transactions>validTxn;
   vector<Block>blockchain;
   for(int i=0;i<txns.size();i++){
    int sendera=mpp1[txns[i].sender];
    int recievera=mpp1[txns[i].reciever];
    int to_send=txns[i].amount;

    if(sendera>=to_send){
        mpp1[txns[i].sender]-=to_send;
        mpp1[txns[i].reciever]+=to_send;
        size++;
        validTxn.push_back(txns[i]);
    }
    if(validTxn.size()==4){
        string Winner=findminer(miner,blocknumber);
        char User=Winner[0];
        if(mpp1.find(User)!=mpp1.end()){
            mpp1[User]+=reward;
        }
        Block newBlock(blocknumber,prev_block_hash,validTxn,miner);
        blockchain.push_back(newBlock);
        prev_block_hash=newBlock.block_hash;
        validTxn.clear();
        blocknumber++;
        
    }

}

if(validTxn.size()!=0){
    string Winner=findminer(miner,blocknumber);
    char User=Winner[0];
    if(mpp1.find(User)!=mpp1.end()){
        mpp1[User]+=reward;
    }   
    Block newBlock(blocknumber, prev_block_hash,validTxn,miner);
    blockchain.push_back(newBlock);
}

return blockchain;
}






int main(){
    int num_acc;
    cin>>num_acc;
    map<char,int>mpp;
    for(int i=0;i<num_acc;i++){
        char account;
        int balance;
        cin>>account>>balance;
        mpp[account]=balance;
    }
    int num_txn;
    cin>>num_txn;

    vector<Transactions>txn;
    for(int i=0;i<num_txn;i++){
        char sender,reciever;
        int balance,extra_data;
        cin>>sender>>reciever>>balance>>extra_data;
        Transactions temp;
        temp.sender=sender;
        temp.reciever=reciever;
        temp.amount=balance;
        temp.incentives=extra_data;
        txn.push_back(temp); 
    }
vector<Miner>miner;
int reward;
cin>>reward;

int m;
cin>>m;

for(int i=0;i<m;i++){
    string miner_name;
    cin>>miner_name;
    int cscore;
    cin>>cscore;
    vector<int>score;
    for(int j=0;j<8;j++){
        int sc;
        cin>>sc;
        score.push_back(sc);
    }
    Miner m1;
    m1.id=miner_name;
    m1.computation_score=cscore;
    m1.block_hash_score_array=score;
miner.push_back(m1);

}


vector<Block>blockchain=createblocks(num_acc,mpp,num_txn,txn,miner,reward);
for (auto& block : blockchain) {
    block.printBlock();
}

    
}
